﻿namespace ProjectManagement.Interfaces
{
    public interface ICommentManagementServices
    {
    }
}
