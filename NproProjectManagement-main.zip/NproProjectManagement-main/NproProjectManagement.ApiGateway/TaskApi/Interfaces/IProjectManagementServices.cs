﻿namespace ProjectManagement.Interfaces
{
    public interface IProjectManagementServices
    {
    }
}
