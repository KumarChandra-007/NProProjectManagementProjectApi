﻿using ProjectManagement.Interfaces;

namespace ProjectManagement.Services
{
    public class ProjectManagementServices : IProjectManagementServices
    {
    }
}
