﻿using ProjectManagement.Interfaces;

namespace ProjectManagement.Services
{
    public class CommentManagementServices : ICommentManagementServices
    {
    }
}
