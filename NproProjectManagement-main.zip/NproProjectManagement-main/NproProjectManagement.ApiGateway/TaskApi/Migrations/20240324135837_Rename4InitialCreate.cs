﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SampleProjectMgmt.Migrations
{
    /// <inheritdoc />
    public partial class Rename4InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
